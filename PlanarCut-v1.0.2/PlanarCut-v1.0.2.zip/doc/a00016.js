var a00016 =
[
    [ "DTWMode", "a00016.html#acff797acf2ec08d0f6518751453cd8e2", [
      [ "VERTEX_BASED", "a00016.html#acff797acf2ec08d0f6518751453cd8e2ad1b041cb55ee7a7d902d047638991f94", null ],
      [ "EDGE_BASED", "a00016.html#acff797acf2ec08d0f6518751453cd8e2a09903e76363ec9eb25fd4721769b0ac5", null ]
    ] ],
    [ "CutShape", "a00016.html#a68ad4cd012c38f7d3e12662fce682ee4", null ],
    [ "~CutShape", "a00016.html#ad293aca8ed4ee90fad7db6ab83367213", null ],
    [ "setDissimilarityMatrix", "a00016.html#a39a6a0ce3f60a9be1318d267d37a355b", null ],
    [ "getMatchingScore", "a00016.html#a8759740ccadb605b22d924f2c0c9f450", null ],
    [ "getMatching", "a00016.html#a6880ca2298450793d473522c20a7eed3", null ]
];