var a00015 =
[
    [ "CutSegment", "a00015.html#a135405b0e11645adef2d53b24acde00f", null ],
    [ "~CutSegment", "a00015.html#a2ad1fcccd8b1ac27549053cc248488a6", null ],
    [ "setImageData", "a00015.html#add5dccff76d4f4d03cdf4a7af379ff49", null ],
    [ "setImageData", "a00015.html#a273918788a65e884296f6c2dde1de4fa", null ],
    [ "setSourceSink", "a00015.html#afd744543aac8af47a9df134569b80358", null ],
    [ "gradient", "a00015.html#aacf6591687eb8d6ecbbc769cec0a711f", null ],
    [ "gradient", "a00015.html#a2a6f6f03d56eaae0c4ee3e3f66a191ca", null ],
    [ "segment", "a00015.html#a781014344a508ef988bca1836e349c39", null ],
    [ "getLabel", "a00015.html#ac5f5144a2f5b6355abd1fac7decd7084", null ],
    [ "getLabels", "a00015.html#ad6d3c208ed3796f318844e6dc253ad07", null ]
];