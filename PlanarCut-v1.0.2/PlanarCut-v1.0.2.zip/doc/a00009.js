var a00009 =
[
    [ "dijkWeight", "a00009.html#a996c5a6bbb2e452a7b8f5d9b61946450", null ],
    [ "node", "a00009.html#ac6a3e47af83258a118dda154d7c3403b", null ],
    [ "heapId", "a00009.html#a8b9c0ca6c0c0adac5f493ed4ba0d0b35", null ],
    [ "heapNr", "a00009.html#ad5be160c05118a9b825d24247ea435a4", null ]
];