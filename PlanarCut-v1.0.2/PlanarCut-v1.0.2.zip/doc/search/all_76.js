var searchData=
[
  ['vertex_5fbased',['VERTEX_BASED',['../a00016.html#acff797acf2ec08d0f6518751453cd8e2ad1b041cb55ee7a7d902d047638991f94',1,'CutShape']]]
];
