var searchData=
[
  ['tag',['tag',['../a00011.html#a9a023ede5be3c9b4ecd679cfb62d334e',1,'CGNode']]],
  ['type',['type',['../a00011.html#a212aac59a25700b3018d2d7d293d6489',1,'CGNode']]]
];
