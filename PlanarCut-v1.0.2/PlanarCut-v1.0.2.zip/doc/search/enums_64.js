var searchData=
[
  ['dtwmode',['DTWMode',['../a00016.html#acff797acf2ec08d0f6518751453cd8e2',1,'CutShape']]]
];
